#ifndef SOLVE_H
#define SOLVE_H

#include "node.h"

node * t10_solve (node *head);

#endif
