#ifndef SOLVE_H
#define SOLVE_H

#include "node.h"

int t2_solve (node *head);

#endif
