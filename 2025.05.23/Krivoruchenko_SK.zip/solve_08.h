#ifndef SOLVE_H
#define SOLVE_H

#include "node.h"

node * t8_solve (node *head);

#endif
