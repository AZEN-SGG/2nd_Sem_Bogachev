#ifndef INIT_F_H
#define INIT_F_H

double f1(int n, int m, int i, int j);
double f2(int n, int m, int i, int j);
double f3(int n, int m, int i, int j);
double f4(int n, int m, int i, int j);

#endif
