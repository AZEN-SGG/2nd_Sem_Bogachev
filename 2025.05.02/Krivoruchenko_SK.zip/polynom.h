#ifndef POLYNOM_H
#define POLYNOM_H

double construct_poly (const double x_0, const int n, const double * restrict X, double * restrict Y);

#endif
