#ifndef SOLVE_H
#define SOLVE_H

int t7_solve (
		double (*f) (double), 
		double x_0, double eps, 
		int m, double *x
		);

#endif
