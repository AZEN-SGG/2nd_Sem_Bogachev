#ifndef SOLVE_H
#define SOLVE_H

int t1_solve(double *a, int m, int n);
int t2_solve(double *a, int m, int n);
int t3_solve(double *a, int m, int n);
int t4_solve(double *a, int m, int n);
int t5_solve(double *a, int m, int n);
int t6_solve(double *a, int m, int n);
int t7_solve(double *a, int m, int n);
int t8_solve(double *a, int m, int n);
int t9_solve(double *a, int m, int n);
int t10_solve(double *a, int m, int n);

#endif
