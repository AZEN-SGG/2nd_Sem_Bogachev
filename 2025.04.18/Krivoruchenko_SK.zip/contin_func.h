#ifndef CONTIN_FUNC_H
#define CONTIN_FUNC_H

double ssin (const double x, const double eps);
double scos (const double x, const double eps);
double sexp (const double x, const double eps);
double fln (const double x, const double eps);

#endif
